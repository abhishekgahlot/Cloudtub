	<script src="home-static/js/jquery-latest.js"></script>
    <script src="home-static/js/bootstrap.min.js"></script>
    <script src="home-static/js/script.js"></script>
    <script type="text/javascript">
    	$('#tryit').click(function(){
	    	
	    	$('#email').val('me@abhishek.it');
	    	$('#pass').val('password');
	    	
    	});
    </script>
</body>
</html>