 	   <link href="home-static/css/bootstrap.css" type="text/css" rel="stylesheet" />
 	   <link href="home-static/css/style.css" type="text/css" rel="stylesheet" />
 	   <link href="home-static/css/font-awesome.css" type="text/css" rel="stylesheet" />
