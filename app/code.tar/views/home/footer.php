 <!-- starts footer -->
    <div id="footer">
        <div class="container">
            <div class="row">
                <div class="span8"><!--span8-->
                    <h3>Want To Work With Us</h3>

                  </div><!--span8-->
                <div class="span4">

                </div>
            </div>
            <hr />
            <div class="row copyright">
                <div class="span5">
                    <h3>Social</h3>
                    <a href="https://www.facebook.com/cloudtub" class="social fb">
                        <i class="i_facebook"></i>
                    </a>
                    <a href="https://www.twitter.com/cloudtub" class="social tw">
                        <i class="i_twitter"></i>
                    </a>
                    <a href="#" class="social yt">
                        <i class="i_youtube"></i>
                    </a>
                </div>
                <div class="span2 offset5 copy">
                    <p>Cloudtub &copy; 2012-2013 </p>
                </div>
            </div>
        </div>
    </div>
    <div class='footer-bar'></div>

    <script src="http://code.jquery.com/jquery-latest.js"></script>
    <script src="home_static/js/bootstrap.min.js"></script>
    <script src="home_static/js/theme.js"></script>
</body>
</html>