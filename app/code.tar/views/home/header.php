<!-- begins navbar -->
<link href='http://fonts.googleapis.com/css?family=Source+Code+Pro:400,600,700' rel='stylesheet' type='text/css'>

	<div class="navbar navbar-fixed-top">
	<div class='top-bar'></div>
      <div class="navbar-inner">
        <div class="container">
    		<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
          	</a>
          	<a class="brand scroller"  href="/">
               <h2 class='logo'>Cloudtub</h2>
            </a>
		  	<div class="nav-collapse collapse">
                <ul class="nav pull-right">
                			<li><a href="/">Home</a></li>
                            <li><a href="features">Features</a></li>
                            <li><a href="pricing">Pricing</a></li>
                            <li><a href="contact">Contact</a></li>

                    <li><a  href="signin">Sign in</a></li>

                    <li>
                        <a  href="signup">Sign up</a>
                    </li>
                </ul>
	        </div>
        </div>
      </div>
    </div>
    <!-- ends navbar -->