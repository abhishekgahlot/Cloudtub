 	<link href="home_static/css/bootstrap.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="home_static/css/theme.css" />
    <link rel="stylesheet" type="text/css" href="home_static/css/animate.css" />
    <link rel="stylesheet" type="text/css" href="home_static/css/external-pages.css" />
</head>
<body>
<a href="#" class="scrolltop">
<span>up</span>
</a>


