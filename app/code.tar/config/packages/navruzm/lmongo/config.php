<?php

return array(

    /*
    |--------------------------------------------------------------------------
    | Default Database Connection Name
    |--------------------------------------------------------------------------
    */



    /*
    |--------------------------------------------------------------------------
    | Database Connections
    |--------------------------------------------------------------------------
    */

    'connections' => array(

        'default' => array(
            'host'     => 'localhost',
            'port'     => '32759',
            'database' => 'cloudtub',
            'username' => 'cloudy',
            'password' => 'darkshadowbellatrix'


        ),
    ),
);